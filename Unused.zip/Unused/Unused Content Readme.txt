This is a folder of content I compiled that was in the files at one stage before being
removed due to not being used in-game. I also included older versions of some files
should the modders wish to create a "legacy" mod using older sounds.

I created the folder in order to make it easier for potential modders to implement stuff
that they wish to make into a mod.

~AgentParadox